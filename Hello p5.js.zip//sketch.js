function setup() {
  createCanvas(windowWidth, windowHeight);
  
}

function draw() {
  background('#742FDC')
  noStroke()
  ellipse(xpos, ypos, 50, 50);
  triangle(0,windowHeight,xpos,ypos,windowWidth,windowHeight)
  xpos = xpos + xdir;
  if (xpos>= windoWidth )
  